package com.josecampos.hablemos;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;

public class MainActivity extends Activity {

    static final int PIDE_MIC = 11, PIDE_AVISOS = 12, FOTO = 21, GALERIA = 22, PERMISO_BURBUJA = 31;

    WebView web;
    Motor motor;
    String idiomaPendiente = null;
    Uri fotoUri;
    boolean listaWeb = false;
    String textoCompartido = null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF0C447C);
        getWindow().setNavigationBarColor(0xFFF1EFE8);
        motor = Motor.de(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                listaWeb = true;
                if (textoCompartido != null) { js("window.textoRecibido&&textoRecibido(" + q(textoCompartido) + ")"); textoCompartido = null; }
            }
        });
        web.addJavascriptInterface(new Puente(), "Android");
        conectarVoz();
        web.loadUrl("file:///android_asset/index.html");
        recibir(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        recibir(i);
    }

    void recibir(Intent i) {
        if (i == null || !Intent.ACTION_SEND.equals(i.getAction())) return;
        String tipo = i.getType();
        if (tipo != null && tipo.startsWith("text/")) {
            String t = i.getStringExtra(Intent.EXTRA_TEXT);
            if (t != null) {
                if (listaWeb) js("window.textoRecibido&&textoRecibido(" + q(t) + ")");
                else textoCompartido = t;
            }
        } else if (tipo != null && tipo.startsWith("image/")) {
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) web.postDelayed(() -> leerImagen(u), 1200);
        }
    }

    void conectarVoz() {
        motor.vozListener = new Motor.VozListener() {
            @Override public void inicio(String id) { js("window.onTts&&onTts(" + q(id) + ",'start',0,0)"); }
            @Override public void rango(String id, int d, int h) { js("window.onTts&&onTts(" + q(id) + ",'range'," + d + "," + h + ")"); }
            @Override public void fin(String id) { js("window.onTts&&onTts(" + q(id) + ",'done',0,0)"); }
        };
    }

    static String q(String s) {
        if (s == null) return "null";
        return JSONObject.quote(s).replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
    }

    void js(String codigo) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(codigo, null); });
    }

    @Override
    protected void onResume() {
        super.onResume();
        conectarVoz();
        if (web != null) web.onResume();
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.stopAll&&stopAll()", null);
            web.onPause();
        }
        motor.callar();
        motor.pararMic();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack?appBack():'exit'", v -> {
            if (v == null || v.contains("exit")) finish();
        });
    }

    // ------------- Micrófono -------------
    void empezarMic(String idioma) {
        motor.escuchar(idioma, new Motor.MicListener() {
            @Override public void parcial(String t) { js("window.onRec&&onRec('partial'," + q(t) + ")"); }
            @Override public void resultado(String json) { js("window.onRec&&onRec('final'," + q(json) + ")"); }
            @Override public void error(String m) { js("window.onRec&&onRec('error'," + q(m) + ")"); }
            @Override public void fin() { js("window.onRec&&onRec('end','')"); }
        });
        js("window.onRec&&onRec('start','')");
    }

    @Override
    public void onRequestPermissionsResult(int codigo, String[] permisos, int[] res) {
        super.onRequestPermissionsResult(codigo, permisos, res);
        if (codigo == PIDE_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && idiomaPendiente != null) {
                empezarMic(idiomaPendiente);
            } else {
                js("window.onRec&&onRec('error'," + q("Sin permiso del micrófono no puedo oírlo.") + ");window.onRec&&onRec('end','')");
            }
            idiomaPendiente = null;
        } else if (codigo == PIDE_AVISOS) {
            abrirBurbuja();
        }
    }

    // ------------- Cámara y galería -------------
    void tomarFoto() {
        try {
            File dir = new File(getCacheDir(), "fotos");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, "foto.jpg");
            fotoUri = FileProvider.getUriForFile(this, "com.josecampos.hablemos.archivos", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, fotoUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, FOTO);
        } catch (Exception e) {
            aviso("No se pudo abrir la cámara.");
        }
    }

    void abrirGaleria() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        try { startActivityForResult(Intent.createChooser(i, "Escoja la foto"), GALERIA); }
        catch (Exception e) { aviso("No se pudo abrir la galería."); }
    }

    @Override
    protected void onActivityResult(int codigo, int res, Intent datos) {
        super.onActivityResult(codigo, res, datos);
        if (codigo == FOTO) {
            if (res == RESULT_OK && fotoUri != null) leerImagen(fotoUri);
            else js("window.onOcr&&onOcr(null)");
        } else if (codigo == GALERIA) {
            if (res == RESULT_OK && datos != null && datos.getData() != null) leerImagen(datos.getData());
            else js("window.onOcr&&onOcr(null)");
        } else if (codigo == PERMISO_BURBUJA) {
            if (Settings.canDrawOverlays(this)) abrirBurbuja();
            else aviso("Sin ese permiso la burbuja no puede flotar sobre WhatsApp.");
        }
    }

    void leerImagen(Uri u) {
        js("window.onOcrEstado&&onOcrEstado(" + q("Leyendo el texto de la foto…") + ")");
        new Thread(() -> {
            try {
                ImageDecoder.Source fuente = ImageDecoder.createSource(getContentResolver(), u);
                Bitmap bmp = ImageDecoder.decodeBitmap(fuente, (dec, info, src) -> {
                    dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                    int m = Math.max(w, h);
                    if (m > 1600) {
                        float k = 1600f / m;
                        dec.setTargetSize(Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)));
                    }
                });
                final Bitmap foto = bmp;
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                        .process(InputImage.fromBitmap(foto, 0))
                        .addOnSuccessListener(texto -> new Thread(() -> enviarOcr(foto, texto)).start())
                        .addOnFailureListener(e -> {
                            js("window.onOcr&&onOcr(null)");
                            aviso("No pude leer el texto de la foto.");
                        });
            } catch (Exception e) {
                js("window.onOcr&&onOcr(null)");
                aviso("No pude abrir la foto.");
            }
        }).start();
    }

    void enviarOcr(Bitmap foto, Text texto) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            foto.compress(Bitmap.CompressFormat.JPEG, 80, bos);
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            JSONObject o = new JSONObject();
            o.put("img", "data:image/jpeg;base64," + b64);
            o.put("w", foto.getWidth());
            o.put("h", foto.getHeight());
            JSONArray bloques = new JSONArray();
            for (Text.TextBlock bl : texto.getTextBlocks()) {
                Rect r = bl.getBoundingBox();
                if (r == null) continue;
                JSONObject x = new JSONObject();
                x.put("t", bl.getText());
                x.put("x", r.left); x.put("y", r.top); x.put("w", r.width()); x.put("h", r.height());
                JSONArray lineas = new JSONArray();
                lineas.put(bl.getLines().size());
                x.put("n", bl.getLines().size());
                bloques.put(x);
            }
            o.put("b", bloques);
            js("window.onOcr&&onOcr(" + q(o.toString()) + ")");
        } catch (Exception e) {
            js("window.onOcr&&onOcr(null)");
        }
    }

    // ------------- Burbuja -------------
    void abrirBurbuja() {
        if (!Settings.canDrawOverlays(this)) {
            aviso("Active \"Mostrar sobre otras apps\" para Hablemos English y vuelva.");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            try { startActivityForResult(i, PERMISO_BURBUJA); } catch (Exception e) { aviso("Abra Ajustes y dele permiso de mostrar sobre otras apps."); }
            return;
        }
        Intent s = new Intent(this, BurbujaService.class);
        startForegroundService(s);
        aviso("Burbuja activa. Ábrala encima de WhatsApp.");
        moveTaskToBack(true);
    }

    void aviso(String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    // ------------- Puente con la página -------------
    class Puente {
        @JavascriptInterface public boolean esApp() { return true; }

        @JavascriptInterface public void speak(String texto, String id, float tono, float vel, String voz, String idioma) {
            motor.hablar(texto, id, tono, vel, voz, idioma);
        }
        @JavascriptInterface public void stopSpeak() { motor.callar(); }
        @JavascriptInterface public String voices() { return motor.vocesJson(); }
        @JavascriptInterface public void setVoice(String nombre, float tono, float vel) { motor.guardarVoz(nombre, tono, vel); }

        @JavascriptInterface public void listen(String idioma) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    idiomaPendiente = idioma;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PIDE_MIC);
                } else empezarMic(idioma);
            });
        }
        @JavascriptInterface public void stopListen() { runOnUiThread(() -> motor.pararMic()); }

        @JavascriptInterface public void translate(String texto, boolean aIngles, String id) {
            runOnUiThread(() -> motor.traducir(texto, aIngles, new Motor.TradListener() {
                @Override public void listo(boolean ok, String t, String err) {
                    js("window.onTr&&onTr(" + q(id) + "," + ok + "," + q(ok ? t : err) + ")");
                }
                @Override public void estado(String m) { js("window.onTrEstado&&onTrEstado(" + q(m) + ")"); }
            }));
        }

        @JavascriptInterface public void photo() { runOnUiThread(MainActivity.this::tomarFoto); }
        @JavascriptInterface public void gallery() { runOnUiThread(MainActivity.this::abrirGaleria); }

        @JavascriptInterface public void copy(String t) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Hablemos English", t));
                if (Build.VERSION.SDK_INT < 33) Toast.makeText(MainActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public String paste() {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm.hasPrimaryClip() && cm.getPrimaryClip() != null && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence c = cm.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                    return c == null ? "" : c.toString();
                }
            } catch (Exception ignored) { }
            return "";
        }
        @JavascriptInterface public void shareText(String t, boolean wa) { runOnUiThread(() -> motor.compartirTexto(t, wa)); }
        @JavascriptInterface public void sendVoice(String t) {
            runOnUiThread(() -> motor.enviarEnVoz(t, (ok, m) -> {
                js("window.onVoiceFile&&onVoiceFile(" + ok + "," + q(m) + ")");
            }));
        }
        @JavascriptInterface public String saveWord(String titulo, String cuerpo) { return motor.guardarWord(titulo, cuerpo); }
        @JavascriptInterface public void bubble() { runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PIDE_AVISOS);
            } else abrirBurbuja();
        }); }
        @JavascriptInterface public void toast(String m) { aviso(m); }
        @JavascriptInterface public void keepScreen(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }
}
