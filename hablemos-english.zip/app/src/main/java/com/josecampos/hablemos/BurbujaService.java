package com.josecampos.hablemos;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;

/** Burbuja flotante que traduce encima de WhatsApp. Solo trabaja mientras está encendida. */
public class BurbujaService extends Service {

    WindowManager wm;
    TextView bola;
    LinearLayout panel;
    WindowManager.LayoutParams pb, pp;
    EditText entrada;
    TextView resultado, estado, direccion;
    Button bMic;
    boolean aIngles = true, escuchando = false, panelVisible = false;
    Motor motor;

    @Override public IBinder onBind(Intent i) { return null; }

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    public void onCreate() {
        super.onCreate();
        motor = Motor.de(this);
        avisoPermanente();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        crearBola();
        crearPanel();
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "parar".equals(i.getAction())) { stopSelf(); }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        try { if (bola != null) wm.removeView(bola); } catch (Exception ignored) { }
        try { if (panelVisible) wm.removeView(panel); } catch (Exception ignored) { }
        motor.pararMic();
        motor.callar();
        super.onDestroy();
    }

    void avisoPermanente() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel("burbuja", "Burbuja traductora", NotificationManager.IMPORTANCE_LOW);
        nm.createNotificationChannel(ch);
        Intent parar = new Intent(this, BurbujaService.class).setAction("parar");
        PendingIntent pi = PendingIntent.getService(this, 1, parar, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, "burbuja")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("Burbuja traductora encendida")
                .setContentText("Toque aquí para apagarla")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(7, n);
    }

    GradientDrawable fondo(int color, int radio, int borde, int colorBorde) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radio));
        if (borde > 0) g.setStroke(dp(borde), colorBorde);
        return g;
    }

    void crearBola() {
        bola = new TextView(this);
        bola.setText("🌎");
        bola.setTextSize(26);
        bola.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF0C447C);
        g.setStroke(dp(3), 0xFFFFFFFF);
        bola.setBackground(g);
        pb = new WindowManager.LayoutParams(dp(58), dp(58),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        pb.gravity = Gravity.TOP | Gravity.START;
        pb.x = dp(6);
        pb.y = dp(260);
        bola.setOnTouchListener(new View.OnTouchListener() {
            float rx, ry; int sx, sy; boolean movio;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = pb.x; sy = pb.y; rx = e.getRawX(); ry = e.getRawY(); movio = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        int nx = sx + (int) (e.getRawX() - rx), ny = sy + (int) (e.getRawY() - ry);
                        if (Math.abs(nx - sx) > dp(8) || Math.abs(ny - sy) > dp(8)) movio = true;
                        if (movio) { pb.x = nx; pb.y = ny; try { wm.updateViewLayout(bola, pb); } catch (Exception ignored) { } }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!movio) alternarPanel();
                        return true;
                }
                return false;
            }
        });
        wm.addView(bola, pb);
    }

    Button boton(String texto, int color, int colorTexto) {
        Button b = new Button(this);
        b.setText(texto);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(colorTexto);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(fondo(color, 12, color == 0xFFFFFFFF ? 1 : 0, 0xFF85B7EB));
        b.setPadding(dp(4), dp(8), dp(4), dp(8));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        return b;
    }

    LinearLayout fila(View... vistas) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.HORIZONTAL);
        for (View v : vistas) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(3), dp(3), dp(3), dp(3));
            f.addView(v, lp);
        }
        return f;
    }

    void crearPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.setBackground(fondo(0xFFFFFFFF, 16, 2, 0xFF185FA5));

        direccion = new TextView(this);
        direccion.setTextSize(15);
        direccion.setTypeface(Typeface.DEFAULT_BOLD);
        direccion.setTextColor(0xFF0C447C);
        direccion.setPadding(dp(4), dp(8), dp(4), dp(8));
        direccion.setOnClickListener(v -> { aIngles = !aIngles; pintarDireccion(); });
        pintarDireccion();
        Button minimizar = boton("—", 0xFFFFFFFF, 0xFF0C447C);
        Button apagar = boton("✕", 0xFFFCEBEB, 0xFF791F1F);
        minimizar.setOnClickListener(v -> alternarPanel());
        apagar.setOnClickListener(v -> stopSelf());
        LinearLayout arriba = new LinearLayout(this);
        arriba.setOrientation(LinearLayout.HORIZONTAL);
        arriba.addView(direccion, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        arriba.addView(minimizar, new LinearLayout.LayoutParams(dp(48), dp(40)));
        LinearLayout.LayoutParams lpA = new LinearLayout.LayoutParams(dp(48), dp(40));
        lpA.setMargins(dp(6), 0, 0, 0);
        arriba.addView(apagar, lpA);
        panel.addView(arriba);

        entrada = new EditText(this);
        entrada.setHint("Escriba o dicte aquí… sin límite");
        entrada.setTextSize(16);
        entrada.setTextColor(0xFF000000);
        entrada.setMinLines(2);
        entrada.setMaxLines(5);
        entrada.setBackground(fondo(0xFFF4F7FB, 10, 1, 0xFFB5D4F4));
        entrada.setPadding(dp(10), dp(8), dp(10), dp(8));
        panel.addView(entrada);

        bMic = boton("🎤 Dictar", 0xFF0F6E56, 0xFFFFFFFF);
        Button pegar = boton("📋 Pegar", 0xFFFFFFFF, 0xFF0C447C);
        Button traducir = boton("⇄ Traducir", 0xFF185FA5, 0xFFFFFFFF);
        bMic.setOnClickListener(v -> dictar());
        pegar.setOnClickListener(v -> pegar());
        traducir.setOnClickListener(v -> traducir());
        panel.addView(fila(bMic, pegar, traducir));

        resultado = new TextView(this);
        resultado.setTextSize(18);
        resultado.setTypeface(Typeface.DEFAULT_BOLD);
        resultado.setTextColor(0xFF042C53);
        resultado.setTextIsSelectable(true);
        resultado.setPadding(dp(4), dp(6), dp(4), dp(2));
        panel.addView(resultado);

        estado = new TextView(this);
        estado.setTextSize(13);
        estado.setTextColor(0xFF5F5E5A);
        estado.setPadding(dp(4), 0, dp(4), dp(4));
        panel.addView(estado);

        Button copiar = boton("📋 Copiar", 0xFF0F6E56, 0xFFFFFFFF);
        Button oir = boton("🔊 Oír", 0xFF185FA5, 0xFFFFFFFF);
        Button voz = boton("💬 Enviar en voz", 0xFFFFFFFF, 0xFF0C447C);
        copiar.setOnClickListener(v -> copiar());
        oir.setOnClickListener(v -> oir());
        voz.setOnClickListener(v -> enviarVoz());
        panel.addView(fila(copiar, oir, voz));

        pp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP;
        pp.y = dp(36);
        pp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
    }

    void pintarDireccion() {
        direccion.setText(aIngles ? "🇨🇴 Español → 🇺🇸 Inglés   ⇄" : "🇺🇸 Inglés → 🇨🇴 Español   ⇄");
    }

    void alternarPanel() {
        try {
            if (panelVisible) { wm.removeView(panel); panelVisible = false; }
            else { wm.addView(panel, pp); panelVisible = true; }
        } catch (Exception ignored) { }
    }

    void dictar() {
        if (escuchando) { motor.pararMic(); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            estado.setText("Abra Hablemos English, toque Dictar una vez y dele permiso al micrófono.");
            return;
        }
        escuchando = true;
        bMic.setText("⏹ Parar");
        estado.setText("Hable ahora…");
        motor.escuchar(aIngles ? "es-CO" : "en-US", new Motor.MicListener() {
            @Override public void parcial(String t) { estado.setText("Oigo: " + t); }
            @Override public void resultado(String json) {
                try {
                    JSONArray a = new JSONArray(json);
                    if (a.length() > 0) {
                        String t = a.getJSONObject(0).getString("t");
                        String antes = entrada.getText().toString().trim();
                        entrada.setText(antes.isEmpty() ? t : antes + " " + t);
                        entrada.setSelection(entrada.getText().length());
                        traducir();
                    }
                } catch (Exception ignored) { }
            }
            @Override public void error(String m) { estado.setText(m); }
            @Override public void fin() { escuchando = false; bMic.setText("🎤 Dictar"); }
        });
    }

    void pegar() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData c = cm.getPrimaryClip();
            if (c != null && c.getItemCount() > 0) {
                CharSequence t = c.getItemAt(0).coerceToText(this);
                if (t != null && t.length() > 0) {
                    entrada.setText(t);
                    traducir();
                    return;
                }
            }
        } catch (Exception ignored) { }
        estado.setText("No encontré nada copiado. Deje oprimido el recuadro blanco y toque Pegar.");
    }

    void traducir() {
        String t = entrada.getText().toString().trim();
        if (t.isEmpty()) { estado.setText("Escriba, dicte o pegue algo primero."); return; }
        estado.setText("Traduciendo…");
        motor.traducir(t, aIngles, new Motor.TradListener() {
            @Override public void listo(boolean ok, String texto, String error) {
                if (ok) { resultado.setText(texto); estado.setText("Listo. Copie o envíelo en voz."); }
                else estado.setText(error);
            }
            @Override public void estado(String m) { estado.setText(m); }
        });
    }

    void copiar() {
        String t = resultado.getText().toString();
        if (t.isEmpty()) { estado.setText("Primero traduzca."); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Traducción", t));
        estado.setText("Copiado. En WhatsApp deje oprimido el recuadro y toque Pegar.");
        if (panelVisible) alternarPanel();
    }

    void oir() {
        String t = resultado.getText().toString();
        if (t.isEmpty()) { estado.setText("Primero traduzca."); return; }
        motor.hablar(t, "burbuja", motor.vozTono(), motor.vozVel(), motor.vozNombre(), aIngles ? "en" : "es");
    }

    void enviarVoz() {
        String ingles = aIngles ? resultado.getText().toString() : entrada.getText().toString();
        if (ingles.trim().isEmpty()) { estado.setText("Primero traduzca."); return; }
        estado.setText("Haciendo el audio en inglés…");
        motor.enviarEnVoz(ingles, (ok, m) -> {
            estado.setText(m);
            if (ok && panelVisible) alternarPanel();
        });
    }
}
