package com.josecampos.hablemos;

import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Motor compartido: voz, micrófono, traductor, audios, Word y Descargas. */
public class Motor {

    public interface VozListener {
        void inicio(String id);
        void rango(String id, int desde, int hasta);
        void fin(String id);
    }

    public interface MicListener {
        void parcial(String texto);
        void resultado(String jsonAlternativas);
        void error(String mensaje);
        void fin();
    }

    public interface TradListener {
        void listo(boolean ok, String texto, String error);
        void estado(String mensaje);
    }

    public interface AudioListener {
        void listo(boolean ok, String mensaje);
    }

    public static final String CARPETA = "MiBarra/Hablemos English";

    private static Motor yo;

    public static synchronized Motor de(Context c) {
        if (yo == null) yo = new Motor(c.getApplicationContext());
        return yo;
    }

    final Context ctx;
    final Handler main = new Handler(Looper.getMainLooper());
    TextToSpeech tts;
    boolean vozLista = false;
    VozListener vozListener;
    final Map<String, Runnable> trabajosArchivo = new HashMap<>();
    SpeechRecognizer mic;
    Translator esEn, enEs;

    private Motor(Context c) {
        ctx = c;
        iniciarVoz();
    }

    void iniciarVoz() {
        tts = new TextToSpeech(ctx, estado -> {
            vozLista = (estado == TextToSpeech.SUCCESS);
            if (vozLista) {
                tts.setLanguage(Locale.US);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {
                        if (id != null && id.startsWith("archivo:")) return;
                        VozListener l = vozListener; if (l != null) l.inicio(id);
                    }
                    @Override public void onDone(String id) {
                        if (id != null && id.startsWith("archivo:")) {
                            Runnable r; synchronized (trabajosArchivo) { r = trabajosArchivo.remove(id); }
                            if (r != null) new Thread(r).start();
                            return;
                        }
                        VozListener l = vozListener; if (l != null) l.fin(id);
                    }
                    @Override public void onError(String id) {
                        if (id != null && id.startsWith("archivo:")) {
                            Runnable r; synchronized (trabajosArchivo) { r = trabajosArchivo.remove(id); }
                            if (r != null) new Thread(r).start();
                            return;
                        }
                        VozListener l = vozListener; if (l != null) l.fin(id);
                    }
                    @Override public void onRangeStart(String id, int desde, int hasta, int cuadro) {
                        if (id != null && id.startsWith("archivo:")) return;
                        VozListener l = vozListener; if (l != null) l.rango(id, desde, hasta);
                    }
                });
            }
        });
    }

    // ---------------- Preferencias de voz ----------------
    SharedPreferences prefs() { return ctx.getSharedPreferences("voz", Context.MODE_PRIVATE); }

    public void guardarVoz(String nombre, float tono, float velocidad) {
        prefs().edit().putString("nombre", nombre == null ? "" : nombre)
                .putFloat("tono", tono).putFloat("vel", velocidad).apply();
    }
    public String vozNombre() { return prefs().getString("nombre", ""); }
    public float vozTono() { return prefs().getFloat("tono", 0.85f); }
    public float vozVel() { return prefs().getFloat("vel", 0.9f); }

    public String vocesJson() {
        JSONArray a = new JSONArray();
        try {
            if (tts == null || !vozLista) return "[]";
            Set<Voice> vs = tts.getVoices();
            if (vs == null) return "[]";
            List<Voice> lista = new ArrayList<>();
            for (Voice v : vs) {
                Locale l = v.getLocale();
                if (l == null || !"en".equals(l.getLanguage())) continue;
                lista.add(v);
            }
            Collections.sort(lista, (x, y) -> x.getName().compareTo(y.getName()));
            for (Voice v : lista) {
                JSONObject o = new JSONObject();
                o.put("n", v.getName());
                o.put("p", v.getLocale().getCountry());
                o.put("red", v.isNetworkConnectionRequired());
                o.put("q", v.getQuality());
                a.put(o);
            }
        } catch (Exception e) { return "[]"; }
        return a.toString();
    }

    void ponerVoz(String nombre, String idioma) {
        if (tts == null) return;
        if ("es".equals(idioma)) {
            int r = tts.setLanguage(new Locale("es", "CO"));
            if (r < 0) tts.setLanguage(new Locale("es", "ES"));
            return;
        }
        if (nombre != null && nombre.length() > 0) {
            try {
                Set<Voice> vs = tts.getVoices();
                if (vs != null) for (Voice v : vs) {
                    if (v.getName().equals(nombre)) { tts.setVoice(v); return; }
                }
            } catch (Exception ignored) { }
        }
        tts.setLanguage(Locale.US);
    }

    public void hablar(String texto, String id, float tono, float vel, String nombreVoz, String idioma) {
        if (tts == null || !vozLista) { VozListener l = vozListener; if (l != null) l.fin(id); return; }
        ponerVoz(nombreVoz, idioma);
        tts.setPitch(tono);
        tts.setSpeechRate(vel);
        Bundle b = new Bundle();
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1f);
        tts.speak(texto, TextToSpeech.QUEUE_FLUSH, b, id);
    }

    public void callar() { if (tts != null) tts.stop(); }

    // ---------------- Micrófono ----------------
    /** Debe llamarse en el hilo principal. */
    public void escuchar(String idioma, MicListener l) {
        if (mic != null) { try { mic.destroy(); } catch (Exception ignored) { } mic = null; }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            l.error("Este celular no tiene reconocimiento de voz. Instale o active la app Google."); l.fin(); return;
        }
        mic = SpeechRecognizer.createSpeechRecognizer(ctx);
        mic.setRecognitionListener(new RecognitionListener() {
            boolean terminado = false;
            void cerrar() { if (!terminado) { terminado = true; l.fin(); } }
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float db) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onError(int e) {
                String m;
                switch (e) {
                    case SpeechRecognizer.ERROR_NO_MATCH: m = "No le entendí. Hable cerquita y claro."; break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: m = "No le oí. Toque y hable de una vez."; break;
                    case SpeechRecognizer.ERROR_NETWORK:
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: m = "El micrófono necesita internet (Wi‑Fi o datos)."; break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: m = "Dele permiso al micrófono."; break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: m = "El micrófono está ocupado. Intente otra vez."; break;
                    default: m = "No le oí bien. Intente otra vez.";
                }
                l.error(m); cerrar();
            }
            @Override public void onResults(Bundle r) {
                try {
                    ArrayList<String> t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    float[] c = r.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
                    JSONArray a = new JSONArray();
                    if (t != null) for (int i = 0; i < t.size(); i++) {
                        JSONObject o = new JSONObject();
                        o.put("t", t.get(i));
                        o.put("c", (c != null && i < c.length && c[i] >= 0) ? c[i] : 0);
                        a.put(o);
                    }
                    l.resultado(a.toString());
                } catch (Exception ex) { l.error("No le oí bien."); }
                cerrar();
            }
            @Override public void onPartialResults(Bundle r) {
                ArrayList<String> t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (t != null && !t.isEmpty()) l.parcial(t.get(0));
            }
            @Override public void onEvent(int tipo, Bundle p) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, idioma);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, idioma);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L);
        try { mic.startListening(i); } catch (Exception e) { l.error("No se pudo abrir el micrófono."); l.fin(); }
    }

    public void pararMic() {
        if (mic != null) { try { mic.stopListening(); } catch (Exception ignored) { } }
    }

    // ---------------- Traductor (Google ML Kit, gratis y dentro del celular) ----------------
    Translator traductor(boolean aIngles) {
        if (aIngles) {
            if (esEn == null) esEn = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.SPANISH).setTargetLanguage(TranslateLanguage.ENGLISH).build());
            return esEn;
        } else {
            if (enEs == null) enEs = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.SPANISH).build());
            return enEs;
        }
    }

    public void traducir(String texto, boolean aIngles, TradListener l) {
        final Translator t = traductor(aIngles);
        l.estado("Preparando el traductor… (la primera vez descarga el idioma)");
        t.downloadModelIfNeeded(new DownloadConditions.Builder().build())
                .addOnSuccessListener(v -> {
                    String[] partes = texto.split("\n", -1);
                    traducirPartes(t, partes, new String[partes.length], 0, l);
                })
                .addOnFailureListener(e -> l.listo(false, null,
                        "No se pudo descargar el idioma. La primera vez necesita internet (Wi‑Fi o datos)."));
    }

    void traducirPartes(Translator t, String[] partes, String[] res, int i, TradListener l) {
        if (i >= partes.length) {
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < res.length; k++) { if (k > 0) sb.append('\n'); sb.append(res[k]); }
            l.listo(true, sb.toString(), null);
            return;
        }
        if (partes[i].trim().isEmpty()) { res[i] = ""; traducirPartes(t, partes, res, i + 1, l); return; }
        t.translate(partes[i])
                .addOnSuccessListener(s -> { res[i] = s; traducirPartes(t, partes, res, i + 1, l); })
                .addOnFailureListener(e -> l.listo(false, null, "No se pudo traducir. Intente otra vez."));
    }

    // ---------------- Guardar en Descargas/MiBarra/Hablemos English ----------------
    public Uri guardarEnDescargas(String sub, String nombre, String tipo, byte[] datos) throws Exception {
        ContentResolver cr = ctx.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, nombre);
        v.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
        String ruta = Environment.DIRECTORY_DOWNLOADS + "/" + CARPETA + (sub == null || sub.isEmpty() ? "" : "/" + sub);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, ruta);
        Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (u == null) throw new Exception("No se pudo crear el archivo");
        try (OutputStream os = cr.openOutputStream(u)) {
            if (os == null) throw new Exception("No se pudo escribir");
            os.write(datos);
        }
        return u;
    }

    static String sello() { return new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()); }

    // ---------------- Word (.docx tamaño carta) ----------------
    static String xml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String parrafo(String texto, boolean negrita, int medio) {
        return "<w:p><w:r><w:rPr>" + (negrita ? "<w:b/>" : "") + "<w:color w:val=\"000000\"/><w:sz w:val=\"" + medio + "\"/></w:rPr>"
                + "<w:t xml:space=\"preserve\">" + xml(texto) + "</w:t></w:r></w:p>";
    }

    public static byte[] crearDocx(String titulo, String cuerpo) throws Exception {
        StringBuilder d = new StringBuilder();
        d.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
         .append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
        d.append(parrafo(titulo, true, 32));
        for (String linea : cuerpo.split("\n", -1)) {
            boolean neg = linea.startsWith("## ");
            d.append(parrafo(neg ? linea.substring(3) : linea, neg, 24));
        }
        d.append("<w:sectPr><w:pgSz w:w=\"12240\" w:h=\"15840\"/>")
         .append("<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>")
         .append("</w:sectPr></w:body></w:document>");
        String tipos = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                + "</Types>";
        String rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                + "</Relationships>";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bos)) {
            z.putNextEntry(new ZipEntry("[Content_Types].xml")); z.write(tipos.getBytes(StandardCharsets.UTF_8)); z.closeEntry();
            z.putNextEntry(new ZipEntry("_rels/.rels")); z.write(rels.getBytes(StandardCharsets.UTF_8)); z.closeEntry();
            z.putNextEntry(new ZipEntry("word/document.xml")); z.write(d.toString().getBytes(StandardCharsets.UTF_8)); z.closeEntry();
        }
        return bos.toByteArray();
    }

    public String guardarWord(String titulo, String cuerpo) {
        try {
            String limpio = titulo.replaceAll("[^A-Za-z0-9áéíóúñÁÉÍÓÚÑ ]", "").trim();
            if (limpio.length() > 30) limpio = limpio.substring(0, 30).trim();
            if (limpio.isEmpty()) limpio = "Traduccion";
            String nombre = limpio + " " + sello() + ".docx";
            guardarEnDescargas("Documentos", nombre,
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document", crearDocx(titulo, cuerpo));
            return "Guardado en Descargas/" + CARPETA + "/Documentos/" + nombre;
        } catch (Exception e) {
            return "ERROR: no se pudo guardar el Word.";
        }
    }

    // ---------------- Audio en inglés para WhatsApp ----------------
    public void enviarEnVoz(String texto, AudioListener l) {
        if (tts == null || !vozLista) { l.listo(false, "La voz del celular no está lista."); return; }
        try {
            File dir = new File(ctx.getCacheDir(), "audios");
            if (!dir.exists()) dir.mkdirs();
            final File wav = new File(dir, "voz.wav");
            if (wav.exists()) wav.delete();
            final String id = "archivo:" + System.currentTimeMillis();
            synchronized (trabajosArchivo) {
                trabajosArchivo.put(id, () -> terminarAudio(wav, l));
            }
            ponerVoz(vozNombre(), "en");
            tts.setPitch(vozTono());
            tts.setSpeechRate(vozVel());
            int r = tts.synthesizeToFile(texto, new Bundle(), wav, id);
            if (r != TextToSpeech.SUCCESS) {
                synchronized (trabajosArchivo) { trabajosArchivo.remove(id); }
                l.listo(false, "No se pudo crear el audio.");
            }
        } catch (Exception e) {
            l.listo(false, "No se pudo crear el audio.");
        }
    }

    void terminarAudio(File wav, AudioListener l) {
        try {
            if (!wav.exists() || wav.length() < 100) { main.post(() -> l.listo(false, "No se pudo crear el audio.")); return; }
            byte[] datos;
            String nombre, tipo;
            try {
                File m4a = new File(wav.getParentFile(), "voz.m4a");
                if (m4a.exists()) m4a.delete();
                wavAM4a(wav, m4a);
                datos = leer(m4a);
                nombre = "Audio " + sello() + ".m4a";
                tipo = "audio/mp4";
            } catch (Exception e) {
                datos = leer(wav);
                nombre = "Audio " + sello() + ".wav";
                tipo = "audio/wav";
            }
            Uri u = guardarEnDescargas("Audios", nombre, tipo, datos);
            final String t = tipo;
            main.post(() -> {
                compartir(u, t);
                l.listo(true, "Audio guardado en Descargas/" + CARPETA + "/Audios");
            });
        } catch (Exception e) {
            main.post(() -> l.listo(false, "No se pudo guardar el audio."));
        }
    }

    static byte[] leer(File f) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) > 0) bos.write(b, 0, n);
            return bos.toByteArray();
        }
    }

    static int le16(byte[] a, int p) { return (a[p] & 0xff) | ((a[p + 1] & 0xff) << 8); }
    static int le32(byte[] a, int p) { return (a[p] & 0xff) | ((a[p + 1] & 0xff) << 8) | ((a[p + 2] & 0xff) << 16) | ((a[p + 3] & 0xff) << 24); }

    /** Convierte el WAV de la voz en M4A (AAC), el formato que WhatsApp reproduce como audio. */
    static void wavAM4a(File wav, File salida) throws Exception {
        byte[] todo = leer(wav);
        int canales = 1, muestras = 22050, datosIni = -1, datosLen = 0;
        int p = 12;
        while (p + 8 <= todo.length) {
            String id = new String(todo, p, 4, StandardCharsets.US_ASCII);
            int len = le32(todo, p + 4);
            if (id.equals("fmt ")) { canales = le16(todo, p + 10); muestras = le32(todo, p + 12); }
            else if (id.equals("data")) { datosIni = p + 8; datosLen = Math.min(len < 0 ? Integer.MAX_VALUE : len, todo.length - datosIni); break; }
            if (len < 0) break;
            p += 8 + len + (len & 1);
        }
        if (datosIni < 0) throw new Exception("wav sin datos");
        MediaFormat fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, muestras, canales);
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        MediaCodec codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codec.start();
        MediaMuxer mux = new MediaMuxer(salida.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        int pista = -1;
        boolean muxIniciado = false, entradaFin = false, salidaFin = false;
        int pos = 0;
        long bytesSeg = (long) muestras * canales * 2L;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        int vueltas = 0;
        while (!salidaFin && vueltas < 200000) {
            vueltas++;
            if (!entradaFin) {
                int ii = codec.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    ByteBuffer buf = codec.getInputBuffer(ii);
                    if (buf != null) {
                        buf.clear();
                        int n = Math.min(buf.remaining(), datosLen - pos);
                        n -= n % (2 * canales);
                        long pts = (pos * 1000000L) / bytesSeg;
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            entradaFin = true;
                        } else {
                            buf.put(todo, datosIni + pos, n);
                            codec.queueInputBuffer(ii, 0, n, pts, 0);
                            pos += n;
                        }
                    }
                }
            }
            int oi = codec.dequeueOutputBuffer(info, 10000);
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                pista = mux.addTrack(codec.getOutputFormat());
                mux.start();
                muxIniciado = true;
            } else if (oi >= 0) {
                ByteBuffer ob = codec.getOutputBuffer(oi);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0 && muxIniciado && ob != null) {
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    mux.writeSampleData(pista, ob, info);
                }
                codec.releaseOutputBuffer(oi, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) salidaFin = true;
            }
        }
        codec.stop();
        codec.release();
        if (muxIniciado) mux.stop();
        mux.release();
        if (!muxIniciado) throw new Exception("sin audio");
    }

    // ---------------- Compartir ----------------
    public void compartir(Uri u, String tipo) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(tipo);
        i.putExtra(Intent.EXTRA_STREAM, u);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        abrirWhatsApp(i);
    }

    public void compartirTexto(String texto, boolean soloWhatsApp) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, texto);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (soloWhatsApp) abrirWhatsApp(i);
        else {
            Intent c = Intent.createChooser(i, "Compartir");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(c);
        }
    }

    void abrirWhatsApp(Intent i) {
        String[] paquetes = {"com.whatsapp", "com.whatsapp.w4b"};
        for (String p : paquetes) {
            try {
                i.setPackage(p);
                ctx.startActivity(i);
                return;
            } catch (ActivityNotFoundException ignored) { }
        }
        i.setPackage(null);
        Intent c = Intent.createChooser(i, "Enviar");
        c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if ((i.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) c.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        ctx.startActivity(c);
    }
}
